package com.springbootpegproject.PersonProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
