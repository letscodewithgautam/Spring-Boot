package com.springbootproject.MySqlBookProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySqlBookProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
