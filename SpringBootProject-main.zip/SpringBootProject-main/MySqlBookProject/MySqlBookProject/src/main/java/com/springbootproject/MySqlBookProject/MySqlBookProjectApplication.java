package com.springbootproject.MySqlBookProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MySqlBookProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySqlBookProjectApplication.class, args);
	}

}
